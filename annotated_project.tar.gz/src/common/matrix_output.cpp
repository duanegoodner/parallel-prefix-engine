// ----------------------------------------------------------------------------
// matrix_output.cpp
//
// Implements matrix printing and formatting logic for both local and distributed
// MPI matrix data.
// ----------------------------------------------------------------------------

