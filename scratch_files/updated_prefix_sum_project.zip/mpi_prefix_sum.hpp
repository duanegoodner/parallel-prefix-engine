#pragma once

#include <vector>


void MyPrefixSum(int local_n, std::vector<int>& sum_matrix);